asteroids-adapter Rev 4.1.0 (Asteroids PCB to Cabinet Adapter) 
------------------------------------------------------------------------------------
 
This is the package for asteroids-adapter rev 4.1.0.
 
Service Requested 
=================
 
   * PCB and assembly to IPC class 3 standards 
   * 0.62 inch FR4, 94V-0 marked 
   * 2 layer stackup to be approved prior to manufacture 
   * ENIG finish, RoHS compliant
 
Standards 
=========
 
RoHS compliant 

Programming and labeling of microcontroller 
===========================================
 
None 

Testing 
======= 
   * Test 100% testing of assemblies 
   * Standard PCB QA (bed of nails, test for shorts and opens) 
 

Tracking 
========
 
As specified in the BOM 
 

Packaging 
=========
 
Standard Packaging 

Production Package 
==================
 
The  ZIP file contains the following files: 
   asteroids-adapter-Rev_4-pcbfab.zip 
   A ZIP file containing Gerbers; drill file; 
   readme.txt 
      readme file containing PCB fabrication directions; fab renderings, etc. 
 
 
   This letter. 
 
Renderings-top-asteroids-adapter-Rev_4.1.0-Production.jpg 
   A JPEG file containing a reference for PCB parts placement, and 3D renderings of the front of the populated board (with components). 
 
Renderings-bottom-asteroids-adapter-Rev_4.1.0-Production.jpg 
   A JPEG file containing a reference for PCB parts placement, and 3D renderings of the back of the populated board (with components). 
 
Model-3D-asteroids-adapter-Rev_4-Production.STEP: 
   An exported 3D STEP file of the PCB with all components fitted. 
 
Schematic-asteroids-adapter-Rev_4.1.0-Production.pdf 
   A PDF file containing the schematics for this PCB. 
 
BOM-asteroids-adapter-Rev_4.1-Production.csv 
   BOM file, csv format 
 
Subdirectory: labels_dir 
   :_labels.doc: Labels for final packaging. 
 
Subdirectory: programming_files_dir 
   empty, not applicable. 
 
Subdirectory containing programming files 
   empty, not applicable 
 
Subdirectory: diagrams_dir 
   empty 
 
Subdirectory containing diagrams or pictures related to production 
   empty 
 
Subdirectory: work_instructions_dir 
   Subdirectory containing work instructions, test procedures, etc.
 
.. figure:: ./Renderings-top-asteroids-adapter-Rev_4.1.0-Production.jpg
 
   TOP side rendering of populated PCB 
.. figure:: ./Renderings-bottom-asteroids-adapter-Rev_4.1.0-Production.jpg
 
   BOTTOM side rendering of populated PCB
